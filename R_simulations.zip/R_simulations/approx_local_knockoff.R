#method='approx_local_knockoff_db' or 'approx_local_knockoff'
approx_local_knockoff <- function(A, Y, q, Sigma, method, Theta=NULL) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) Theta is the inverse
  # complexity is n^3
  
if (is.null(Theta)) {
	Theta = solve(Sigma)
	}
  
  # Step 1: Compute debiased Lasso solution
  mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) # alpha=1 means lasso (alpha=0 is ridge regression)
 #cv.glmnet performs cross-validation
lam=mod_cv$lambda.min
model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

alpha <- as.numeric(model.lasso$beta) # fitted values using lasso

cat("alpha computed", 0, "\n")
R <- Y-A %*% alpha

if (method == 'approx_local_knockoff_db') {
 Z0 <- Debiased_U(A, Y, alpha, R, lam, Sigma, Theta)
 } else{
 	Z0=alpha
 	}
cat("alpha^U or alpha computed", 1, "\n")

  
  # Step 2: Initialize variables
  hat_gamma <- rep(0, length(Z0))
  X <- matrix(0, nrow = nrow(A), ncol = ncol(A))
  S <- which(abs(alpha) > 0.000000001)
  P_A <- A[, S] %*% solve(t(A[, S])%*%A[, S]) %*% t(A[, S])
  
  # Step 3: Loop over each variable
  Z <- rep(0, length(Z0))
if (method == 'approx_local_knockoff_db') {
  for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
    mean_vector <- -A[,-j] %*% t(Theta[j,-j,drop = FALSE])/Theta[j,j]
	
# Generate samples from the multivariate Gaussian distribution, so that X will be B[,j]

	X <- rnorm(n)
	X <- sqrt(1/Theta[j,j])* X +mean_vector
    
    # Update the test statistic Z
 
   		Z[j] <- approx_Debiased_U(A, X, P_A, R, alpha[j], Theta, j)
#cat("solved j=", j, "\n")
		}
    	} else {# method is approx_local_knockoff
    for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
    mean_vector <- -A[,-j] %*% t(Theta[j,-j,drop = FALSE])/Theta[j,j]
	
# Generate samples from the multivariate Gaussian distribution, so that X will be B[,j]

	X <- rnorm(n)
	X <- sqrt(1/Theta[j,j])* X +mean_vector
    
    # Update the test statistic Z

    	
    	Z[j] <- approx_U(A, X, P_A, R, lam, alpha[j], j, Theta)    		
    }
   }
  
  # Step 4: Choose T
  T <- choose_threshold(abs(Z), abs(Z0), q)


  # Step 5: Output selected set of variables
  # Close all open plots
#graphics.off()
#  plot(hat_alpha_U)
#  dev.new()
# plot(hat_gamma)
  selected_variables <- which(abs(Z0) > T)
  return(selected_variables)
}






##########################################################################
local_knockoff <- function(A, Y, q, Sigma, Theta=NULL) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) Theta is the inverse
  # complexity is n^3
  
if (is.null(Theta)) {
	Theta = solve(Sigma)
	}
  
  # Step 1: Compute debiased Lasso solution
 	mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) 
	lam=mod_cv$lambda.min
	model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

	alpha <- as.numeric(model.lasso$beta) # fitted values using lasso
 	Z0=alpha
  
  # Step 3: Loop over each variable
  Z <- rep(0, length(Z0))
    for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
    mean_vector <- -A[,-j] %*% t(Theta[j,-j,drop = FALSE])/Theta[j,j]
	
	# Generate samples from the multivariate Gaussian distribution, so that X will be B[,j]

	X <- rnorm(n)
	B_j <- sqrt(1/Theta[j,j])* X +mean_vector
	A_j <- A
    A_j[, j] <- B_j
    
    # Update the test statistic Z
    model.lasso <- glmnet(A_j,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)
    gamma <- as.numeric(model.lasso$beta)  	
    Z[j]<- gamma[j]	
   }
  
  # Step 4: Choose T
  T <- choose_threshold(abs(Z), abs(Z0), q)

  selected_variables <- which(abs(Z0) > T)
  return(selected_variables)
}



