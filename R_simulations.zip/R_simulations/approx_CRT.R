approx_CRT_db <- function(A, Y, q, Sigma, K, Theta=NULL) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) Theta is the inverse
  # complexity is Kn^3
  	if (is.null(Theta)) {
	Theta = solve(Sigma)
	}
  
  # Step 1: Compute debiased Lasso solution
  mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) # alpha=1 means lasso (alpha=0 is ridge regression)
 #cv.glmnet performs cross-validation
lam=mod_cv$lambda.min
model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

alpha <- as.numeric(model.lasso$beta) # fitted values using lasso

cat("alpha computed", 0, "\n")
R <- Y-A %*% alpha
 hat_alpha_U <- Debiased_U(A, Y, alpha, R, lam, Sigma, Theta)
cat("alpha^U computed", 1, "\n")

p_vals <- rep(0, length(hat_alpha_U)) 

S <- which(abs(alpha) > 0.000000001)
P_A <- A[, S] %*% solve(t(A[, S]) %*% A[, S]) %*% t(A[, S])
mean_vectors <- matrix(0, nrow = nrow(A), ncol = ncol(A))
T1s <- matrix(0, nrow = nrow(A), ncol = ncol(A))
for (j in 1:ncol(A)) {
	mean_vectors[,j] <- -A[,-j] %*% t(Theta[j,-j, drop = FALSE])/Theta[j,j]
	T1s[,j] = (diag(n) - P_A) %*% A[, j] * alpha[j]
	}

for (k in 1:K){
  # Step 2: Initialize variables
  hat_gamma <- rep(0, length(hat_alpha_U))
#  X <- matrix(0, nrow = nrow(A), ncol = ncol(A))

  # Step 3: Loop over each variable
  for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
	# Generate samples from the multivariate Gaussian distribution, so that X will be B[,j]

	check_B <- sqrt(1/Theta[j,j])*rnorm(n)
	X <- check_B +mean_vectors[,j]
    
    # Update gamma_j
    hat_gamma[j] <- approx_Debiased_U(A, X, P_A, R, alpha[j], Theta, j, check_B, T1s[,j])
#cat("solved j=", j, "\n")
  }
  p_vals <-p_vals+ as.numeric(abs(hat_gamma) > abs(hat_alpha_U))
}
p_vals <- (1+p_vals)/(K+1)
#cat("p_vals", p_vals, "\n")

  # Step 4: BH
adjusted_p_values <- p.adjust(p_vals, method = "BH")
selected_set <- which(adjusted_p_values < q)
  return(selected_set)
}



##################################
approx_CRT <- function(A, Y, q, Sigma, K, Theta=NULL) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) Theta is the inverse
  # complexity is Kn^3
  
  	if (is.null(Theta)) {
	Theta = solve(Sigma)
	}
  
  # Step 1: Compute debiased Lasso solution
  mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) # alpha=1 means lasso (alpha=0 is ridge regression)
 #cv.glmnet performs cross-validation
lam=mod_cv$lambda.min
model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

alpha <- as.numeric(model.lasso$beta) # fitted values using lasso

cat("alpha computed", 0, "\n")
R <- Y-A %*% alpha

p_vals <- rep(0, length(alpha)) 

S <- which(abs(alpha) > 0.000000001)
P_A <- A[, S] %*% solve(t(A[, S])%*%A[, S]) %*% t(A[, S])
mean_vectors <- matrix(0, nrow = nrow(A), ncol = ncol(A))
T1s <- matrix(0, nrow = nrow(A), ncol = ncol(A))
T2s <- matrix(0, nrow = nrow(A), ncol = ncol(A))
T3s <- matrix(0, nrow = nrow(A), ncol = 1)
for (j in 1:ncol(A)) {
	mean_vectors[,j] <- -A[,-j] %*% t(Theta[j,-j, drop = FALSE])/Theta[j,j]
	T1s[,j] = (diag(n) - P_A) %*% A[, j] * alpha[j]
	T2s[,j] = (diag(n) - P_A) %*% mean_vectors[,j]
	T3s[j] = t(mean_vectors[,j]) %*%(diag(n) - P_A) %*% mean_vectors[,j]
	}

for (k in 1:K){
  # Step 2: Initialize variables
  hat_gamma <- rep(0, length(alpha))

  # Step 3: Loop over each variable
  for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
	# Generate samples from the multivariate Gaussian distribution, so that X will be B[,j]

	check_B <- sqrt(1/Theta[j,j])*rnorm(n)
	X <- check_B +mean_vectors[,j]
    
    # Update gamma_j
    hat_gamma[j] <- approx_U(A, X, P_A, R, lam, alpha[j], j, Theta, check_B, T1s[,j], T2s[,j], T3s[j])
#cat("solved j=", j, "\n")
  }
  p_vals <-p_vals+ as.numeric(abs(hat_gamma) > abs(alpha))
}
p_vals <- (1+p_vals)/(K+1)
#cat("p_vals", p_vals, "\n")

  # Step 4: BH
adjusted_p_values <- p.adjust(p_vals, method = "BH")
selected_set <- which(adjusted_p_values < q)
  return(selected_set)
}


