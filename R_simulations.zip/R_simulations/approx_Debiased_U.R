#If the arguments check_B and T1 = (diag(n) - P_A) %*% A[, j] * hat_alpha_j are provided, then the complexity=p.
#If check_B is not provided, then T1 will be computed by the function, and the complexity is p^2.

approx_Debiased_U <- function(A, X, P_A, R, hat_alpha_j, Theta, j, check_B = NULL, T1 =NULL) {
  n <- nrow(A)  # Number of rows in matrix A
  sj <- setdiff(1:ncol(A), j)  # Set sj as {1, 2, ..., p} excluding j
  
  # Compute check_B
   if (is.null(check_B)) {
        # Code to execute if check_B is not specified
  		check_B <- X + A[, sj] %*% (Theta[sj, j] /Theta[j, j])
  		T1 = (diag(n) - P_A) %*% A[, j] * hat_alpha_j
  		denominator <- (1/n) * t(check_B) %*% (diag(n) - P_A) %*% X
    } else {# fastmode if check_B and T1 are specified
    	k <- sum(diag(P_A))
    	denominator <- (1-k/n)/Theta[j, j]
    }  
  
  # Compute hat_beta_U_j
  numerator <- (1/n) * t(check_B) %*% R + (1/n) * t(check_B) %*% T1
  hat_beta_U_j <- numerator / denominator
  
  return(hat_beta_U_j)
}
