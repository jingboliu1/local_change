
# choose method: 'knockoff','knockoff_db' or 'approx_local_knockoff'
#'approx_local_knockoff_db', 'approx_CRT' 'approx_CRT_db' 'local_knockoff'
method <- 'approx_CRT_db' 
maxiter=50
q <- 0.1
rho_cutoff <-0.5
g_lasso_lam <- 0.2 #0.1
set.seed(123)# set random seed

source("sslasso_code/lasso_inference.R")
source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("approx_CRT.R")
source("Debiased_U.R")
source("choose_threshold.R")
source("knockoff.R")
source("approx_U.R")
source("solve_sdp.R")

install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
install_if_missing("caret")
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 
library(Matrix)
library("Rdsdp")
library(glasso)

# Read the entire CSV file with headers
data <- read.csv("riboflavin/riboflavin.csv", header = TRUE)

# Extract the first row for y
y_data <- data[1, -1]
#y_data <- y_data[,-1]
y<- as.numeric(unlist(y_data))

# Extract the remaining rows for X
X_data <- data[-1, -1]
X<- as.numeric(unlist(X_data))
X <- matrix(X, nrow = length(X)/length(y), ncol = length(y), byrow = FALSE)
X <- t(X)

# exclude highly correlated columns
#r1=r
#diag(r1)<-0
#r2=r1[,S_truth0]
#max_cor <- apply(abs(r2), 1, max)
#S_keep <- which(max_cor<0.3)
#reduced_set <- union(S_truth0, S_keep)
#A <- A[,reduced_set]
#n=nrow(A)
#p=ncol(A)
#S_truth <-1:s
#a0 <- numeric(p)
#a0[1:s] <- a00[S_truth0]
r=cor(X)
high_corr <- findCorrelation(r, cutoff = rho_cutoff, verbose = FALSE)
A <- X[, -high_corr]
n=nrow(A)
p=ncol(A)

# normalize the means of X, A and y and the variance of X, A
X <- apply(X, 2, function(col) col - mean(col))
X <- sweep(X, 2, apply(X, 2, sd), "/")
A <- apply(A, 2, function(col) col - mean(col))
A <- sweep(A, 2, apply(A, 2, sd), "/")
Y <- y - mean(y)

# we first solve the lasso and use its solution as the ground-truth signal
mod_cv <- cv.glmnet(X, Y, alpha=1, standardize=FALSE, intercept=FALSE) 
#lam=mod_cv$lambda.min
lam =0.0001
 model.lasso <- glmnet(X,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

a0 <- as.numeric(model.lasso$beta) # fitted values using lasso
a0 <- a0[ -high_corr]
#cat("truth computed", 0, "\n")
S_truth <- which(abs(a0) > 0.000000001)
s <- length(S_truth)
cat("s=",s ,"\n")

# estimate the variance 
predicted <- predict(model.lasso, s = lam, newx = X)
residuals <- Y - predicted
sigma_hat <- as.numeric(sqrt(var(residuals)))

Sigma <- t(A)%*%A/n
#M <- InverseLinfty(Sigma, n)
M <- glasso(Sigma, rho = g_lasso_lam)$wi

if (method == 'knockoff' || method == 'knockoff_db') {
Theta <- sqrtm(t(M)%*%M)$B
S <- create.solve_sdp(solve(Theta))
}

fdr_avg <- numeric(1)
power_avg <- numeric(1)

# we evalue the FDR by simulating random samples
for(iter in 1:maxiter) {

Y <- A %*% a0 + sigma_hat*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

if (method == 'approx_local_knockoff' || method == 'approx_local_knockoff_db') {
	H1 <- approx_local_knockoff(A, Y, q, Sigma, method, M)
} 
else if (method == 'knockoff' || method == 'knockoff_db') {
	H1<- knockoff(A, Y, q, Sigma,Theta, S, method)
}
else if (method == 'approx_CRT_db') {
	K=p
	H1<- approx_CRT_db(A, Y, q, Sigma, K, M)
	}
else if (method == 'approx_CRT') {
	K=p
	H1<- approx_CRT(A, Y, q, Sigma, K, M)
	}
else if (method == 'local_knockoff') {
	H1<- local_knockoff(A, Y, q, Sigma, M)
	}
else {
  print("Invalid method")
}

num_fd <- length(setdiff(H1, S_truth))
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_fd / num_variables_in_H1
power <- length(intersect(H1, S_truth))/s

cat("iter:", iter, "\n")
cat("False Discovery Rate (FDR):", FDR, "\n")
cat("power:", power, "\n")
fdr_avg <- fdr_avg+FDR
power_avg <- power_avg+power
}

cat("method:", method, "\n")
cat("lam:",lam, "\n")
cat("g_lasso_lam:",g_lasso_lam, "\n")
cat("rho_cutoff:",rho_cutoff, "\n")
cat("s:",s, "\n")
cat("p:",p, "\n")
cat("fdr_avg:", fdr_avg/maxiter, "\n")
cat("power_avg:", power_avg/maxiter, "\n")







