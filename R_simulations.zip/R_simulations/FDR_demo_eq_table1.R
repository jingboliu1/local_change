# compare the FDR of knockoff and approx_local_knockoff
# choose method: 'knockoff','knockoff_db' or 'approx_local_knockoff'
#'approx_local_knockoff_db', 'approx_CRT' 'approx_CRT_db' 
method <- 'approx_CRT_db' 
p=300
n=200
s=20
q= 0.1
ep=50
ap=1/p
maxiter=50
sig = 1/sqrt(p)
A_val=0.2
K=p
set.seed(123)# set random seed

source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("approx_CRT.R")
source("Debiased_U.R")
source("choose_threshold.R")
source("knockoff.R")
source("approx_U.R")


install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 



Theta<- ap*(matrix(1, nrow = p, ncol = p)+ep*diag(p))
Sigma = solve(Theta)

fdr_avg <- numeric(1)
power_avg <- numeric(1)

for(iter in 1:maxiter) {
A0 <-matrix(rnorm(n*p) , nrow = n, ncol = p) # generate gaussian random matrix
A <- A0 %*% sqrtm(Sigma)$B
random_subset <- sample(1:p, s)
a0 <- numeric(p)
a0[random_subset] <- A_val/sqrt(n)
dim(a0) <- c(p,1)
Y <- A %*% a0 + sig*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

if (method == 'approx_local_knockoff' || method == 'approx_local_knockoff_db') {
	H1 <- approx_local_knockoff(A, Y, q, Sigma, method)
} 
else if (method == 'knockoff' || method == 'knockoff_db') {
	if (ep > p - 1) {
    	S <- rep((1+1/ep*(p-1))/ap/(ep+p), times =p)
	} else {
    	S <- rep(2/ap/(p+ep)*0.999, times = p)
	}
	H1<- knockoff(A, Y, q, Sigma,Theta, S, method)
}
else if (method == 'approx_CRT_db') {
	H1<- approx_CRT_db(A, Y, q, Sigma, K)
	}
else if (method == 'approx_CRT') {
	H1<- approx_CRT(A, Y, q, Sigma, K)
	}
else {
  print("Invalid method")
}


num_fd <- length(setdiff(H1, random_subset))
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_fd / num_variables_in_H1
power <- length(intersect(H1, random_subset))/s

cat("iter:", iter, "\n")
cat("False Discovery Rate (FDR):", FDR, "\n")
cat("power:", power, "\n")
fdr_avg <- fdr_avg+FDR
power_avg <- power_avg+power
}
cat("fdr_avg:", fdr_avg/maxiter, "\n")
cat("power_avg:", power_avg/maxiter, "\n")


