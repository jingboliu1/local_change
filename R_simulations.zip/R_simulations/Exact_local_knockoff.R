library(MASS)

Exact_local_knockoff <- function(A, Y, lambda, q, Sigma, Theta) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # lambda: Positive regularization parameter
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) Theta is the inverse
  # complexity is n^4
  
  # Step 1: Compute debiased Lasso solution
  hat_alpha_U <- Debiased_U(A, Y, lambda, Sigma)
  
  # Step 2: Initialize variables
  hat_gamma <- rep(0, length(hat_alpha_U))
  X <- matrix(0, nrow = nrow(A), ncol = ncol(A))
  
  # Step 3: Loop over each variable
  for (j in 1:ncol(A)) {
    # Sample X from the conditional distribution
    mean_vector <- -A[,-j] %*% Theta[-j,j]/Theta[j,j]
	covariance_matrix <- 1/Theta[j,j] * diag(n)  
	
# Generate samples from the multivariate Gaussian distribution
	X <- mvrnorm(mean_vector, covariance_matrix)
    
    # Construct matrix B by replacing the j-th column of A with X
    B <- A
    B[, j] <- X
    
    # Compute debiased Lasso solution for B
    hat_beta_U <- compute_debiased_lasso(B, Y, lambda, Sigma)
    
    # Update gamma_j
    hat_gamma[j] <- hat_beta_U[j]
  }
  
  # Step 4: Choose T
  T <- choose_threshold(hat_gamma, hat_alpha_U, q)
  
  # Step 5: Output selected set of variables
  selected_variables <- which(abs(hat_alpha_U) > T)
  return(selected_variables)
}

# Helper function to choose threshold T
choose_threshold <- function(hat_gamma, hat_alpha_U, q) {
  # Combine the absolute values of hat_gamma and hat_alpha_U
  TT <- union(abs(hat_gamma), abs(hat_alpha_U))
  
  # Sort TT in ascending order
  TT <- sort(TT)
  
  # Initialize the smallest t to be the first element of TT
  t <- TT[1]
  
  # Iterate through TT to find the smallest t
  for (i in 1:length(TT)) {
    num_gamma_gt_t <- sum(abs(hat_gamma) > t)
    num_alpha_U_gt_t <- sum(abs(hat_alpha_U) > t)
    
    # Check if the condition is met
    if (num_gamma_gt_t / num_alpha_U_gt_t <= q) {
      break  # Smallest t found, exit the loop
    } else {
      t <- TT[i + 1]  # Update t to the next element in TT
    }
  }
 }
