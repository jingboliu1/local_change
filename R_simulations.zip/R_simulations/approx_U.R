#If the arguments check_B and 
#T1 = (diag(n) - P_A) %*% A[, j] * hat_alpha_j 
#T2 = (diag(n) - P_A) %*% mean_val_j
#T3 = t(mean_val_j) %*%(diag(n) - P_A) %*% mean_val_j  are provided, then the complexity=p.
#If check_B is not provided, then the above terms will be computed, so that the complexity is p^2.

approx_U <- function(A, X, P_A, R, lam, hat_alpha_j, j, Theta, check_B = NULL, T1 =NULL, T2=NULL, T3=NULL) {
  n <- nrow(A)  # Number of rows in matrix A
  sj <- setdiff(1:ncol(A), j)  # Set sj as {1, 2, ..., p} excluding j
  
  # Compute check_B
   if (is.null(check_B)) {
        # Code to execute if check_B is not specified
  		check_B <- X + A[, sj] %*% (t(Theta[j, sj, drop = FALSE]) /Theta[j, j])
  		T1 = (diag(n) - P_A) %*% A[, j] * hat_alpha_j
  		denominator <- (1/n) * t(X) %*% (diag(n) - P_A) %*% X
  		numerator <- (1/n) * t(X) %*% R +(1/n) * t(X) %*% (diag(n) - P_A) %*% A[, j]*hat_alpha_j
    } else {# fastmode if check_B and T1~T3 are specified
    	k <- sum(diag(P_A))   	
    	denominator <- (1-k/n)/Theta[j, j]+ 2/n*t(check_B)%*%T2 + T3/n
    	numerator <- (1/n) * t(X) %*% R +1/n*t(X)%*%T1
    }  
  
  # Compute hat_beta_j
  hat_beta_j <- S_func(numerator / denominator, lam/denominator)
  
  return(hat_beta_j)
}
