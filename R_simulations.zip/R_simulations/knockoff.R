library(MASS)

knockoff <- function(A, Y, q, Sigma,Theta, S, method) {
  # Input:
  # A: n x p matrix
  # Y: n x 1 vector
  # q: FDR threshold
  # Sigma: p x p matrix (Assumed known) 
  n = nrow(A)
  p = ncol(A)
  
SigmaU <- matrix(0, nrow = 2 * p, ncol = 2 * p)
SigmaU[1:p, 1:p] <- Sigma
SigmaU[(p + 1):(2 * p), (p + 1):(2 * p)] <- Sigma
SigmaU[1:p, (p + 1):(2 * p)] <- Sigma - diag(S)
SigmaU[(p + 1):(2 * p), 1:p] <- Sigma - diag(S)

cat("dim of S:", dim(diag(S)), "\n")
A_hat=A%*%(diag(p)-Theta%*%diag(S)) 
A_hat <- A_hat +matrix(rnorm(n*p) , nrow = n, ncol = p)%*% sqrtm(2*diag(S)-diag(S)%*%Theta%*%diag(S)#+0.000001*diag(p)
)$B # generate gaussian random matrix
A_U <- matrix(0, nrow = n, ncol = 2*p)
A_U[,1:p] <- A
A_U[,(p+1):(2*p)] <-A_hat
  
  # Compute Lasso solution
  mod_cv <- cv.glmnet(A_U, Y, alpha=1, standardize=FALSE, intercept=FALSE) # alpha=1 means lasso (alpha=0 is ridge regression)
 #cv.glmnet performs cross-validation
lam=mod_cv$lambda.min
model.lasso <- glmnet(A_U,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

Z <- as.numeric(model.lasso$beta) # fitted values using lasso
if (method == 'knockoff_db') {
Z <- Z+1/(n-sum(abs(Z)>0.000001))*solve(SigmaU)%*%t(A_U)%*%(Y-A_U%*%Z)
}

W=numeric(p)
  # Step 2: compute symmetric statistics
  for (j in 1:p) {
    W[j]=abs(Z[j])-abs(Z[j+p])
  }
  
  # Step 3: Choose T
  T <- choose_threshold(-W, W, q)

  selected_variables <- which(W > T)
  return(selected_variables)
}
