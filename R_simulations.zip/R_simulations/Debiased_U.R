# Input data
# A: n x p matrix
# Y: n x 1 vector
# Sigma: p x p matrix
# complexity is n^3

Debiased_U <- function(A, Y, alpha, R, lam, Sigma, Theta=NULL) {

matrix_dimensions <- dim(A)

# Extract the number of rows and columns
n <- matrix_dimensions[1]
p <- matrix_dimensions[2]

#R <- Y-A %*% alpha
  
S <- which(abs(alpha) > 0.000000001)
cat("size of S:", length(S), "\n")

# Compute Theta (the inverse of Sigma), Omega, Pi, and P
if (is.null(Theta)) {
	Theta = solve(Sigma)
	}
Omega <- t(A[, S]) %*% A[, S]
Pi <- solve(Omega)
P <- A[, S] %*% Pi %*% t(A[, S])

# Initialize an empty vector to store the results
alpha_U <- numeric(p)
#print(S)

#print(dim(Pi))
for (j in 1:p) {
  if (j %in% S) {
    # Compute P_j when j is in S
    S_j <- setdiff(S, j)
    i <- which(S == j)
    #SS_j <- 1:length(S)
    #SS_j <- SS_j[-i]
	#cat("length(SS_j)", length(SS_j), "\n")	    
	#print(SS_j)
#	cat("length(S_j)", length(S_j), "\n")
#    print(S_j)
#	cat("dim(A[, S_j])", dim(A[, S_j]), "\n")
#	cat("dim(...)", dim(Pi[-i, i] /Pi[i, i] %*% Pi[i, -i]), "\n")
    P_j <- P -
           A[, S] %*% Pi[, i] %*% t(A[, j]) -
           A[, j] %*% (Pi[i, -i] %*% t(A[, S_j])) -
           (A[, S_j] %*% Pi[-i, i]) %*% (Pi[i, -i] %*% t(A[, S_j]))/Pi[i, i]
  } else {
    # Set P_j as P when j is not in S
    P_j <- P
  }
  
  # Compute alpha_U_j
  check_A_j <- A[, j] + A[, -j] %*% t(Theta[j, -j, drop = FALSE]) /Theta[j, j]
  alpha_U[j] <- alpha[j] + 1/((1 / n) * t(check_A_j) %*% (diag(n) - P_j) %*% check_A_j) / Theta[j, j] * Theta[j, ] %*% (t(A) %*% R) / n
}  
return(alpha_U)
}

# Output: alpha_U
