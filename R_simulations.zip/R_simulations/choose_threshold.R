# Helper function to choose threshold T
choose_threshold <- function(hat_gamma_abs, hat_alpha_U_abs, q) {
  # Combine the absolute values of hat_gamma and hat_alpha_U
  TT <- union(abs(hat_gamma_abs), abs(hat_alpha_U_abs))
  
  # Sort TT in ascending order
  TT <- sort(TT)
  
  # Initialize the smallest t to be the first element of TT
  t <- TT[1]
  
  # Iterate through TT to find the smallest t
  for (i in 1:length(TT)) {
    num_gamma_gt_t <- sum(hat_gamma_abs > t)
    num_alpha_U_gt_t <- max(sum(hat_alpha_U_abs > t),1)
    
    # Check if the condition is met
    if (num_gamma_gt_t / num_alpha_U_gt_t <= q) {
      break  # Smallest t found, exit the loop
    } else {
      t <- TT[i + 1]  # Update t to the next element in TT
    }
  }
#    cat("i", i, "\n")
#    cat("t", t, "\n")
    return(t)
 }