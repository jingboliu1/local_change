# choose method: 'knockoff','knockoff_db' or 'approx_local_knockoff'
#'approx_local_knockoff_db', 'approx_CRT' 'approx_CRT_db' 'local_knockoff'
method <- 'approx_local_knockoff_db' 
maxiter=50
q <- 0.1
rho_cutoff <-0.9
g_lasso_lam <- 0.2 #0.1
set.seed(123)# set random seed

library(lars)
data(diabetes)
X <- diabetes$x
y <- diabetes$y
X_expanded <- poly(X, degree = 2, coefs = NULL, raw = TRUE, simple = FALSE)
r=cor(X_expanded)
high_corr <- findCorrelation(r, cutoff = rho_cutoff, verbose = FALSE)
A <- X_expanded[, -high_corr]

# normalize the means of X and y and the variance of X
A <- apply(A, 2, function(col) col - mean(col))
A <- sweep(A, 2, apply(A, 2, sd), "/")
Y <- y - mean(y)
p<-ncol(A)
n<-nrow(A)

# we first solve the lasso and use its solution as the ground-truth signal
mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) 
lam=mod_cv$lambda.min
#lam =0.02
 model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

a0 <- as.numeric(model.lasso$beta) # fitted values using lasso
#cat("truth computed", 0, "\n")
S_truth <- which(abs(a0) > 0.000000001)
s <- length(S_truth)
cat("s=",s ,"\n")

# estimate the variance 
predicted <- predict(model.lasso, s = lam, newx = A)
residuals <- Y - predicted
sigma_hat <- as.numeric(sqrt(var(residuals)))

Sigma <- t(A)%*%A/n
#M <- InverseLinfty(Sigma, n)
M <- glasso(Sigma, rho = g_lasso_lam)$wi

if (method == 'knockoff' || method == 'knockoff_db') {
Theta <- sqrtm(t(M)%*%M)$B
S <- create.solve_sdp(solve(Theta))
}

fdr_avg <- numeric(1)
power_avg <- numeric(1)

# we evalue the FDR by simulating random samples
for(iter in 1:maxiter) {

Y <- A %*% a0 + sigma_hat*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

if (method == 'approx_local_knockoff' || method == 'approx_local_knockoff_db') {
	H1 <- approx_local_knockoff(A, Y, q, Sigma, method, M)
} 
else if (method == 'knockoff' || method == 'knockoff_db') {
	H1<- knockoff(A, Y, q, Sigma,Theta, S, method)
}
else if (method == 'approx_CRT_db') {
	K=p
	H1<- approx_CRT_db(A, Y, q, Sigma, K, M)
	}
else if (method == 'approx_CRT') {
	K=p
	H1<- approx_CRT(A, Y, q, Sigma, K, M)
	}
else if (method == 'local_knockoff') {
	H1<- local_knockoff(A, Y, q, Sigma, M)
	}
else {
  print("Invalid method")
}

num_fd <- length(setdiff(H1, S_truth))
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_fd / num_variables_in_H1
power <- length(intersect(H1, S_truth))/s

cat("iter:", iter, "\n")
cat("False Discovery Rate (FDR):", FDR, "\n")
cat("power:", power, "\n")
fdr_avg <- fdr_avg+FDR
power_avg <- power_avg+power
}

cat("method:", method, "\n")
cat("lam:",lam, "\n")
cat("g_lasso_lam:",g_lasso_lam, "\n")
cat("rho_cutoff:",rho_cutoff, "\n")
cat("s:",s, "\n")
cat("p:",p, "\n")
cat("fdr_avg:", fdr_avg/maxiter, "\n")
cat("power_avg:", power_avg/maxiter, "\n")


Sys.sleep(2) # for example
system("say 'Process complete.'")
