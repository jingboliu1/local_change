#setwd("/Users/jingboliu/Documents/Res2019_knockoff/R_simulations")
.libPaths(c(Sys.getenv("R_LIBS_USER"), .libPaths()))
library(foreach)
library(knockoff)
# choose method: 'knockoff','knockoff_db' or 'approx_local_knockoff'
#'approx_local_knockoff_db', 'approx_CRT' 'approx_CRT_db' 'local_knockoff' 'oatk'
source("guan_oatk.R")
source("guan_regression.R")
source("guan_data.R")
#method <- 'approx_local_knockoff' 
method <- readline(prompt = "Enter method: ")
maxiter=50
q <- 0.1
g_lasso_lam <- 0.2 #0.1
set.seed(123)# set random seed

source("sslasso_code/lasso_inference.R")
source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("approx_CRT.R")
source("Debiased_U.R")
source("choose_threshold.R")
source("knockoff.R")
source("approx_U.R")
source("solve_sdp.R")

install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
install_if_missing("caret")
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 
library(Matrix)
library("Rdsdp")
library(glasso)

# load dataset
dat <- getHIVDataWithY()

A <- dat$X
y <- dat$y

n=nrow(A)
p=ncol(A)

# normalize the means of X and y and the variance of A
A <- apply(A, 2, function(col) col - mean(col))
A <- sweep(A, 2, apply(A, 2, sd), "/")
Y <- y - mean(y)

# we first solve the lasso and use its solution as the ground-truth signal
mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) 
#lam=mod_cv$lambda.min
lam =0.01
 model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

a0 <- as.numeric(model.lasso$beta) # fitted values using lasso
#cat("truth computed", 0, "\n")
S_truth <- which(abs(a0) > 0.000000001)
s <- length(S_truth)
cat("s=",s ,"\n")

# estimate the variance 
predicted <- predict(model.lasso, s = lam, newx = A)
residuals <- Y - predicted
sigma_hat <- as.numeric(sqrt(var(residuals)))

Sigma <- t(A)%*%A/n
#M <- InverseLinfty(Sigma, n)
M <- glasso(Sigma, rho = g_lasso_lam)$wi

if (method == 'knockoff' || method == 'knockoff_db') {
Theta <- sqrtm(t(M)%*%M)$B
S <- create.solve_sdp(solve(Theta))
}

fdr_avg <- numeric(1)
power_avg <- numeric(1)

start <- Sys.time()

# we evalue the FDR by simulating random samples
for(iter in 1:maxiter) {

Y <- A %*% a0 + sigma_hat*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector


if (method == 'approx_local_knockoff' || method == 'approx_local_knockoff_db') {
	H1 <- approx_local_knockoff(A, Y, q, Sigma, method, M)
} 
else if (method == 'knockoff') {
	#H1<- knockoff(A, Y, q, Sigma,Theta, S, method)
    mu <- colMeans(A)
    Xk <- create.gaussian(A, mu = mu, Sigma = cov(A))
    W  <- stat.glmnet_coefdiff(A, Xk, Y)
    T  <- knockoff.threshold(W, fdr = q)
    H1 <- which(W >= T)
}
else if (method == 'approx_CRT_db') {
	K=p
	H1<- approx_CRT_db(A, Y, q, Sigma, K, M)
	}
else if (method == 'approx_CRT') {
	K=p
	H1<- approx_CRT(A, Y, q, Sigma, K, M)
	}
else if (method == 'local_knockoff') {
	H1<- local_knockoff(A, Y, q, Sigma, M)
	}
else if (method == 'oatk'){
    res <- oatk(y,A) #_screen_lasso
    H1 <- res$rej
    }
else if (method == 'gm_low_d'){
    res <- gm_low_d(y,A) 
    H1 <- res$rej
    }
else {
  print("Invalid method")
}

num_fd <- length(setdiff(H1, S_truth))
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_fd / num_variables_in_H1
power <- length(intersect(H1, S_truth))/s

cat("iter:", iter, "\n")
cat("False Discovery Rate (FDR):", FDR, "\n")
cat("power:", power, "\n")
fdr_avg <- fdr_avg+FDR
power_avg <- power_avg+power
}

cat("method:", method, "\n")
cat("lam:",lam, "\n")
cat("g_lasso_lam:",g_lasso_lam, "\n")
cat("s:",s, "\n")
cat("p:",p, "\n")
cat("fdr_avg:", fdr_avg/maxiter, "\n")
cat("power_avg:", power_avg/maxiter, "\n")

end <- Sys.time()
print(end - start)
           
cat(
  "method:", method, "\n",
  "lam:", lam, "\n",
  "s:", s, "\n",
  "fdr_avg:", fdr_avg/maxiter, "\n",
  "power_avg:", power_avg/maxiter, "\n",
  "runtime:", as.numeric(end - start, units = "secs"), "seconds\n\n",
  file = "results.txt",
  append = TRUE
)





