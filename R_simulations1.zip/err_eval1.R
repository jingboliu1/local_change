# test accuracy of the approximation when \check{B} follows a 3-point distribution. Requires defining the dimension scale factor alpha and the probability pr

.libPaths(c(Sys.getenv("R_LIBS_USER"), .libPaths()))
install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
library(IRdisplay)
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 

##################### generate \check{B} #####################
gen_matrix <- function(n, p, pr) {
  vals <- c(sqrt(1/pr), -sqrt(1/pr), 0)
  probs <- c(pr/2, pr/2, 1 - pr)
  
  X <- matrix(
    sample(vals, size = n * p, replace = TRUE, prob = probs),
    nrow = n,
    ncol = p
  )
  
  return(X)
}


##################### experiment #####################

#alpha=0.7
p=1000*alpha #1200#400
skip=10*alpha #12
p_count=floor(p/skip)
n=800*alpha #1000#500#200
s=400*alpha #500#250#50
sig=0.1
#lam = 0.01
rho = 0.5
Sigma <- matrix(0, nrow=p, ncol=p)
for(i in 1:p) {
    for(j in 1:p) {
        Sigma[i, j] <- rho^abs(i - j)
    }
}
Sigma_inv = solve(Sigma)


A0 <-matrix(rnorm(n*p) , nrow = n, ncol = p) # generate gaussian random matrix
A <- A0 %*% sqrtm(Sigma)$B
#a0 <- c(rep(1,s),rep(0,p-s))
a0 <- c(rnorm(s), rep(0, p-s))
dim(a0) <- c(p,1)
Y <- A %*% a0 + sqrt(n)*sig*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

mod_cv <- cv.glmnet(A, Y, alpha=1, standardize=FALSE, intercept=FALSE) # alpha=1 means lasso (alpha=0 is ridge regression)
 #cv.glmnet performs cross-validation
lam=mod_cv$lambda.min
model.lasso <- glmnet(A,Y,lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)

a <- as.numeric(model.lasso$beta) # fitted values using lasso
R <- Y-A %*% a
k <- model.lasso$df

#B0 <-matrix(rnorm(n*p) , nrow = n, ncol = p)
B0 <- gen_matrix(n, p, pr)
B_check <- B0 %*% sqrtm(solve(diag(diag(Sigma_inv))))$B

b_d <- numeric(p_count)
b <- numeric(p_count)
b_d1 <- numeric(p_count)
beta <- numeric(p_count)
beta_d <- numeric(p_count)
different_signs_count <- numeric(p_count)
for (jj in 1:p_count) {
	j <- jj*skip
	predict_j <-solve(Sigma[-j, -j]) %*% Sigma[-j, j]
	B_j <- B_check[, j] + A[, -j] %*% predict_j
nonzero_indices <- which(a != 0)
nonzero_indices <- nonzero_indices[nonzero_indices != j]
A_zcj <- A[, nonzero_indices]
	G_j <- t(A_zcj) %*% A_zcj /n 
	G_j_inv <- solve(G_j)
	u <- t(A_zcj) %*% A[, j]/n
	v <- t(A_zcj) %*% B_j/n
	P_j <- A_zcj %*% G_j_inv %*% t(A_zcj)/n
	b_d[jj]<- t(B_check[,j])%*%R/n + t(B_check[,j])%*%(diag(n)-P_j)%*%A[,j]/n*a[j]
	b_d[jj]<- b_d[jj]/(t(B_check[,j])%*%(diag(n)-P_j)%*%B_j)*n
	b_d1[jj] <- t(B_check[,j])%*%R*Sigma_inv[j,j]/(n-k)
	
	c1 <- t(B_j) %*% (diag(n)-P_j)%*%B_j/n 
	b[jj] <- t(B_j) %*% R/n + t(B_j)%*%(diag(n)-P_j)%*%A[,j]/n* a[j]
	b[jj] <-S_func(b[jj]/c1,lam/c1)

    # Replace j-th column of X with j-th column of B
    A_j <- A
    A_j[, j] <- B_j
    
    # Perform lasso regression
    lasso_model <- glmnet(A_j, Y, lambda = lam, alpha=1, standardize=FALSE, intercept=FALSE)  # alpha=1 indicates lasso
    
    coef_j <- lasso_model$beta
    
    # Store the j-th coordinate of the lasso solution to beta
    beta[jj] <- coef_j[j]  
    k_j <- lasso_model$df
    nonzero_indices_b <- which(coef_j != 0)
	nonzero_indices_b <- nonzero_indices_b[nonzero_indices_b != j]
	A_zcj_b <- A[, nonzero_indices_b]
	G_j_b <- t(A_zcj_b) %*% A_zcj_b /n 
	P_j_b <- A_zcj_b %*% solve(G_j_b) %*% t(A_zcj_b)/n
    beta_d[jj] <- coef_j[j]+n/(t(B_check[,j])%*%(diag(n)-P_j_b)%*%B_j)/Sigma_inv[j,j]*Sigma_inv[j,]%*%t(A_j)%*%(Y-A_j%*%coef_j)/n
    different_signs_count[jj]<- sum(sign(coef_j) != sign(a))
}

#normalized_err_d <- sqrt(sum((beta_d-b_d)^2)/p)
normalized_err_d <- sum((beta_d-b_d)^2)/sum((beta_d)^2)
print(normalized_err_d)

cat(
  "alpha=", alpha, ", ",
  "pr=", pr, ", ",
  "normalized_err_d=", normalized_err_d, "\n",
  file = "results2.txt",
  append = TRUE
)



