# compare the FDR of local_knockoff and approx_local_knockoff
setwd("/Users/jingboliu/Documents/Res2019_knockoff/R_simulations")
source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("Debiased_U.R")


install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 

p=300
n=300
s=20
sig=1
#lam = 0.1
rho = 0.5
q= 0.1
A_val =4.5

Sigma <- matrix(0, nrow=p, ncol=p)
for(i in 1:p) {
    for(j in 1:p) {
        Sigma[i, j] <- rho^abs(i - j)
    }
}
Theta = solve(Sigma)

fdr_avg <- numeric(1)
power_avg <- numeric(1)

for(iter in 1:100) {
A0 <-matrix(rnorm(n*p) , nrow = n, ncol = p) # generate gaussian random matrix
A <- A0 %*% sqrtm(Sigma)$B
random_subset <- sample(1:p, s)
a0 <- numeric(p)
a0[random_subset] <- A_val/sqrt(n)
dim(a0) <- c(p,1)
Y <- A %*% a0 + sig*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

H1 <- approx_local_knockoff(A, Y, q, Sigma) 
num_fd <- length(setdiff(H1, random_subset))
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_fd / num_variables_in_H1
power <- length(intersect(H1, random_subset))/s

cat("iter:", iter, "\n")
cat("False Discovery Rate (FDR):", FDR, "\n")
cat("power:", power, "\n")
fdr_avg <- fdr_avg+FDR
power_avg <- power_avg+power
}
cat("fdr_avg:", fdr_avg/100, "\n")
cat("power_avg:", power_avg/100, "\n")

Sys.sleep(2) # for example
system("say 'Process complete.'")

#A=8
#fdr_avg: 0.123102 
#power_avg: 0.9965 

#A=3
#fdr_avg: 0.2077592 
#power_avg: 0.1755 

#A=4.5
#fdr_avg: 0.1182985 
#power_avg: 0.5855 

# A=6 
#fdr_avg: 0.109786 
#power_avg: 0.901 
