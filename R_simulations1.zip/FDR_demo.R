# compare the FDR of local_knockoff and approx_local_knockoff
setwd("/Users/jingboliu/Documents/Res2019_knockoff/R_simulations")
source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("Debiased_U.R")


install_if_missing <- function(pkg){
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}
install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
library(SparseDC)
library(glmnet)
library(MASS) # for the matrix() function
library(pracma) # dot()
library(expm) # for sqrtm function 

p=1000#120
n=500#100
s=100#50
sig=0.1
#lam = 0.1
rho = 0
q= 0.1

Sigma <- matrix(0, nrow=p, ncol=p)
for(i in 1:p) {
    for(j in 1:p) {
        Sigma[i, j] <- rho^abs(i - j)
    }
}
Theta = solve(Sigma)


A0 <-matrix(rnorm(n*p) , nrow = n, ncol = p) # generate gaussian random matrix
A <- A0 %*% sqrtm(Sigma)$B
#a0 <- c(rep(1,s),rep(0,p-s))
a0 <- c(rnorm(s), rep(0, p-s))
dim(a0) <- c(p,1)
Y <- A %*% a0 + sqrt(n)*sig*matrix(rnorm(n*1) , nrow = n, ncol = 1) # gaussian random vector

H1 <- approx_local_knockoff(A, Y, q, Sigma) 
num_elements_gt_s <- sum(H1 > s)
num_variables_in_H1 <- max(length(H1),1)
FDR <- num_elements_gt_s / num_variables_in_H1

cat("False Discovery Rate (FDR):", FDR, "\n")

Sys.sleep(2) # for example
system("say 'Process complete.'")
