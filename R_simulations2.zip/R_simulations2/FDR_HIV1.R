#setwd("/Users/jingboliu/Documents/Res2019_knockoff/R_simulations")
.libPaths(c(Sys.getenv("R_LIBS_USER"), .libPaths()))

library(foreach)
library(knockoff)

# choose method:
# 'knockoff', 'knockoff_db', 'approx_local_knockoff',
# 'approx_local_knockoff_db', 'approx_CRT', 'approx_CRT_db',
# 'local_knockoff', 'oatk', 'gm_low_d'
# method <- "knockoff"; source("FDR_HIV1.R")
# method <- "approx_local_knockoff"; source("FDR_HIV1.R")
# method <- "approx_local_knockoff_db"; source("FDR_HIV1.R")
# method <- "approx_CRT"; source("FDR_HIV1.R")
# method <- "approx_CRT_db"; source("FDR_HIV1.R")

valid_methods <- c(
  "knockoff",
  "knockoff_db",
  "approx_local_knockoff",
  "approx_local_knockoff_db",
  "approx_CRT",
  "approx_CRT_db",
  "local_knockoff",
  "oatk",
  "gm_low_d"
)

if (!exists("method")) {
  stop("Please define method before sourcing this file, e.g. method <- 'oatk'; source('FDR_HIV.R')")
}

method <- trimws(method)

if (!(method %in% valid_methods)) {
  cat("Invalid method entered:", method, "\n")
  cat("Valid methods are:\n")
  print(valid_methods)
  stop("Invalid method")
}

source("guan_oatk.R")
source("guan_regression.R")
source("guan_data.R")

maxiter <- 50
q <- 0.1
g_lasso_lam <- 0.2

set.seed(123)

source("sslasso_code/lasso_inference.R")
source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("approx_CRT.R")
source("Debiased_U.R")
source("choose_threshold.R")
source("knockoff.R")
source("approx_U.R")
source("solve_sdp.R")

install_if_missing <- function(pkg) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
install_if_missing("caret")
install_if_missing("MASS")
install_if_missing("pracma")
install_if_missing("Rdsdp")
install_if_missing("glasso")

library(SparseDC)
library(glmnet)
library(MASS)
library(pracma)
library(expm)
library(Matrix)
library(caret)
library(Rdsdp)
library(glasso)

# load dataset
dat <- getHIVDataWithY()

A <- dat$X
y <- dat$y

n <- nrow(A)
p <- ncol(A)

# normalize the means of A and y and the variance of A
A <- apply(A, 2, function(col) col - mean(col))
A <- sweep(A, 2, apply(A, 2, sd), "/")
Y <- y - mean(y)

# solve the lasso and use its solution as the ground-truth signal
mod_cv <- cv.glmnet(A, Y, alpha = 1, standardize = FALSE, intercept = FALSE)

lam <- 0.01
model.lasso <- glmnet(A, Y, lambda = lam, alpha = 1, standardize = FALSE, intercept = FALSE)

a0 <- as.numeric(model.lasso$beta)
S_truth <- which(abs(a0) > 0.000000001)
s <- length(S_truth)

cat("s =", s, "\n")
cat("p =", p, "\n")

# estimate the variance
predicted <- predict(model.lasso, s = lam, newx = A)
residuals <- Y - predicted
sigma_hat <- as.numeric(sqrt(var(residuals)))

Sigma <- t(A) %*% A / n
M <- glasso(Sigma, rho = g_lasso_lam)$wi

if (method == "knockoff" || method == "knockoff_db") {
  Theta <- sqrtm(t(M) %*% M)$B
  S <- create.solve_sdp(solve(Theta))
}

fdr_vals <- numeric(maxiter)
power_vals <- numeric(maxiter)
num_selected_vals <- numeric(maxiter)
num_fd_vals <- numeric(maxiter)

start <- Sys.time()

# evaluate FDR by simulating random samples
for (iter in 1:maxiter) {
  
  Y <- A %*% a0 + sigma_hat * matrix(rnorm(n), nrow = n, ncol = 1)
  
  if (method == "approx_local_knockoff" || method == "approx_local_knockoff_db") {
    H1 <- approx_local_knockoff(A, Y, q, Sigma, method, M)
    
  } else if (method == "knockoff") {
    mu <- colMeans(A)
    Xk <- create.gaussian(A, mu = mu, Sigma = cov(A))
    W <- stat.glmnet_coefdiff(A, Xk, Y)
    T <- knockoff.threshold(W, fdr = q)
    H1 <- which(W >= T)
    
  } else if (method == "knockoff_db") {
    H1 <- knockoff(A, Y, q, Sigma, Theta, S, method)
    
  } else if (method == "approx_CRT_db") {
    K <- p
    H1 <- approx_CRT_db(A, Y, q, Sigma, K, M)
    
  } else if (method == "approx_CRT") {
    K <- p
    H1 <- approx_CRT(A, Y, q, Sigma, K, M)
    
  } else if (method == "local_knockoff") {
    H1 <- local_knockoff(A, Y, q, Sigma, M)
    
  } else if (method == "oatk") {
    res <- oatk(y, A)
    H1 <- res$rej
    
  } else if (method == "gm_low_d") {
    res <- gm_low_d(y, A)
    H1 <- res$rej
  }
  
  num_fd <- length(setdiff(H1, S_truth))
  num_selected <- length(H1)
  
  FDP <- num_fd / max(num_selected, 1)
  power <- length(intersect(H1, S_truth)) / s
  
  fdr_vals[iter] <- FDP
  power_vals[iter] <- power
  num_selected_vals[iter] <- num_selected
  num_fd_vals[iter] <- num_fd
  
  cat("iter:", iter, "\n")
  cat("False Discovery Proportion (FDP):", FDP, "\n")
  cat("power:", power, "\n")
  cat("num_selected:", num_selected, "\n")
  cat("num_false_discoveries:", num_fd, "\n\n")
}

fdr_avg <- mean(fdr_vals)
fdr_se <- sd(fdr_vals) / sqrt(maxiter)
fdr_ci_lower <- fdr_avg - 1.96 * fdr_se
fdr_ci_upper <- fdr_avg + 1.96 * fdr_se

power_avg <- mean(power_vals)
power_se <- sd(power_vals) / sqrt(maxiter)
power_ci_lower <- power_avg - 1.96 * power_se
power_ci_upper <- power_avg + 1.96 * power_se

selected_avg <- mean(num_selected_vals)
fd_avg <- mean(num_fd_vals)

end <- Sys.time()
runtime <- end - start

cat("method:", method, "\n")
cat("lam:", lam, "\n")
cat("g_lasso_lam:", g_lasso_lam, "\n")
cat("s:", s, "\n")
cat("p:", p, "\n")
cat("n:", n, "\n")
cat("maxiter:", maxiter, "\n")

cat("FDR_avg:", fdr_avg, "\n")
cat("FDR_se:", fdr_se, "\n")
cat("FDR_95_CI:", "[", fdr_ci_lower, ",", fdr_ci_upper, "]\n")

cat("power_avg:", power_avg, "\n")
cat("power_se:", power_se, "\n")
cat("power_95_CI:", "[", power_ci_lower, ",", power_ci_upper, "]\n")

cat("avg_num_selected:", selected_avg, "\n")
cat("avg_num_false_discoveries:", fd_avg, "\n")
cat("runtime:", as.character(runtime), "\n")

cat(
  "method:", method, "\n",
  "dataset: HIV\n",
  "lam:", lam, "\n",
  "g_lasso_lam:", g_lasso_lam, "\n",
  "q:", q, "\n",
  "s:", s, "\n",
  "p:", p, "\n",
  "n:", n, "\n",
  "maxiter:", maxiter, "\n",
  "FDR_avg:", fdr_avg, "\n",
  "FDR_se:", fdr_se, "\n",
  "FDR_95_CI_lower:", fdr_ci_lower, "\n",
  "FDR_95_CI_upper:", fdr_ci_upper, "\n",
  "power_avg:", power_avg, "\n",
  "power_se:", power_se, "\n",
  "power_95_CI_lower:", power_ci_lower, "\n",
  "power_95_CI_upper:", power_ci_upper, "\n",
  "avg_num_selected:", selected_avg, "\n",
  "avg_num_false_discoveries:", fd_avg, "\n",
  "runtime:", as.numeric(end - start, units = "secs"), "seconds\n\n",
  file = "result_hiv.txt",
  append = TRUE
)