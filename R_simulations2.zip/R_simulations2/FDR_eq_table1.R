.libPaths(c(Sys.getenv("R_LIBS_USER"), .libPaths()))

# choose method: 
# method <- "knockoff"; source("FDR_eq_table1.R")
# method <- "knockoff_db"; source("FDR_eq_table1.R")
# method <- "approx_local_knockoff"; source("FDR_eq_table1.R")
# method <- "approx_local_knockoff_db"; source("FDR_eq_table1.R")
# method <- "approx_CRT"; source("FDR_eq_table1.R")
# method <- "approx_CRT_db"; source("FDR_eq_table1.R")

if (!exists("method")) {
    stop("Please define method before calling source().")
}

p <- 300
n <- 200
s <- 20
maxiter <- 50
q <- 0.1
ep <- 50
ap <- 1 / p

sig <- 1 / sqrt(p)
A_val <- 0.5
K <- p

set.seed(123)

source("approx_Debiased_U.R")
source("approx_local_knockoff.R")
source("approx_CRT.R")
source("Debiased_U.R")
source("choose_threshold.R")
source("knockoff.R")
source("approx_U.R")

install_if_missing <- function(pkg) {
  if (!require(pkg, character.only = TRUE)) {
    install.packages(pkg, dependencies = TRUE)
    library(pkg, character.only = TRUE)
  }
}

install_if_missing("glmnet")
install_if_missing("SparseDC")
install_if_missing("expm")
install_if_missing("Matrix")
install_if_missing("MASS")
install_if_missing("pracma")

library(SparseDC)
library(glmnet)
library(MASS)
library(pracma)
library(expm)
library(Matrix)

Theta <- ap * (matrix(1, nrow = p, ncol = p) + ep * diag(p))
Sigma <- solve(Theta)

fdr_vals <- numeric(maxiter)
power_vals <- numeric(maxiter)
num_selected_vals <- numeric(maxiter)
num_fd_vals <- numeric(maxiter)

start <- Sys.time()

for (iter in 1:maxiter) {
  A0 <- matrix(rnorm(n * p), nrow = n, ncol = p)
  A <- A0 %*% sqrtm(Sigma)$B
  
  random_subset <- sample(1:p, s)
  a0 <- numeric(p)
  a0[random_subset] <- A_val / sqrt(n)
  dim(a0) <- c(p, 1)
  
  Y <- A %*% a0 + sig * matrix(rnorm(n), nrow = n, ncol = 1)
  
  if (method == "approx_local_knockoff" || method == "approx_local_knockoff_db") {
    H1 <- approx_local_knockoff(A, Y, q, Sigma, method)
    
  } else if (method == "knockoff" || method == "knockoff_db") {
    if (ep > p - 1) {
      S <- rep((1 + (p - 1) / ep) / ap / (ep + p), times = p)
    } else {
      S <- rep(2 / ap / (p + ep) * 0.999, times = p)
    }
    H1 <- knockoff(A, Y, q, Sigma, Theta, S, method)
    
  } else if (method == "approx_CRT_db") {
    H1 <- approx_CRT_db(A, Y, q, Sigma, K)
    
  } else if (method == "approx_CRT") {
    H1 <- approx_CRT(A, Y, q, Sigma, K)
    
  } else {
    stop("Invalid method")
  }
  
  num_fd <- length(setdiff(H1, random_subset))
  num_selected <- length(H1)
  
  FDP <- num_fd / max(num_selected, 1)
  power <- length(intersect(H1, random_subset)) / s
  
  fdr_vals[iter] <- FDP
  power_vals[iter] <- power
  num_selected_vals[iter] <- num_selected
  num_fd_vals[iter] <- num_fd
  
  cat("iter:", iter, "\n")
  cat("FDP:", FDP, "\n")
  cat("power:", power, "\n")
  cat("num_selected:", num_selected, "\n")
  cat("num_false_discoveries:", num_fd, "\n\n")
}

fdr_avg <- mean(fdr_vals)
fdr_se <- sd(fdr_vals) / sqrt(maxiter)
fdr_ci_lower <- fdr_avg - 1.96 * fdr_se
fdr_ci_upper <- fdr_avg + 1.96 * fdr_se

power_avg <- mean(power_vals)
power_se <- sd(power_vals) / sqrt(maxiter)
power_ci_lower <- power_avg - 1.96 * power_se
power_ci_upper <- power_avg + 1.96 * power_se

selected_avg <- mean(num_selected_vals)
fd_avg <- mean(num_fd_vals)

end <- Sys.time()
runtime <- end - start

cat("method:", method, "\n")
cat("maxiter:", maxiter, "\n")
cat("FDR_avg:", fdr_avg, "\n")
cat("FDR_se:", fdr_se, "\n")
cat("FDR_95_CI:", "[", fdr_ci_lower, ",", fdr_ci_upper, "]\n")
cat("power_avg:", power_avg, "\n")
cat("power_se:", power_se, "\n")
cat("power_95_CI:", "[", power_ci_lower, ",", power_ci_upper, "]\n")
cat("avg_num_selected:", selected_avg, "\n")
cat("avg_num_false_discoveries:", fd_avg, "\n")
cat("runtime:", as.character(runtime), "\n")

cat(
  "method:", method, "\n",
  "p:", p, "\n",
  "n:", n, "\n",
  "s:", s, "\n",
  "q:", q, "\n",
  "ep:", ep, "\n",
  "A_val:", A_val, "\n",
  "maxiter:", maxiter, "\n",
  "FDR_avg:", fdr_avg, "\n",
  "FDR_se:", fdr_se, "\n",
  "FDR_95_CI_lower:", fdr_ci_lower, "\n",
  "FDR_95_CI_upper:", fdr_ci_upper, "\n",
  "power_avg:", power_avg, "\n",
  "power_se:", power_se, "\n",
  "power_95_CI_lower:", power_ci_lower, "\n",
  "power_95_CI_upper:", power_ci_upper, "\n",
  "avg_num_selected:", selected_avg, "\n",
  "avg_num_false_discoveries:", fd_avg, "\n",
  "runtime:", as.character(runtime), "\n\n",
  file = "result1.txt",
  append = TRUE
)